package Query_Builder;

public class TempTable extends BaseTable{
    public TempTable(String name){
        this.tableName=new TableName(name);
    }
}
